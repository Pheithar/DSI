export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCGB8PtlmDLzwmTMi2SeF4SiSC6cJ_bOxk ",
    authDomain: "h3lp-me.firebaseio.com",
    databaseURL: "https://h3lp-me.firebaseio.com",
    projectId: "h3lp-me",
    storageBucket: "h3lp-me.appspot.com",
    messagingSenderId: "96012255337"
  }
};
